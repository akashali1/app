Summary
=======

Just few scripts that will make you life easier ...

Goal
====

AWS API related scripts, Can be used as ref point for students in Architecting or better Sysops class

PreReq
======

  * AWS Python CLI tools
  * Access / Secert Key with IAM Policy (See specific policy requirments per script)

Usage
=====

Just execute the script with no arguments to list the usage and options 
