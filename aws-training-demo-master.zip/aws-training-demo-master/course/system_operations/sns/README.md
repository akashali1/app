Summary
=======
Just a simple SNS demo , you will need:

 * AWS CLI Tools (Python Version)
 * Access Keys / Secret Keys that needs a minimum of : Create Topics, Send Message to Topics

Might be used an a short interactive demo, Just to show how powerful and simple SNS can be used in certain automation processes!

Comments are welcome !
