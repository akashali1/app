<h1>AWS developer course examples</h1>


Here you can find a few examples that may be useful when teaching the Dev course. They're mostly implemented in the form 
of jUnit tests but actually they don't relay heavily into asserting conditions. 

<ul>
<li><b>DynamoDBTest</b> demostrates how to use the DynamoDB high level API, among other things.
<li><b>S3Test</b> includes a multiupload demo using the TransferManager.
<li><b>SESTest</b> will help you to show how to send mail using AWS and the javax.mail API.
</ul>

Feel free to use the code. And of course, all improvements will be appreciated!

jv
