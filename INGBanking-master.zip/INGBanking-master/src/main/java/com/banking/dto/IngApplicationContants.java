package com.banking.dto;

public class IngApplicationContants {

	public final static String Credit = "CREDIT";
	public final static String Debit = "DEBIT";
}
