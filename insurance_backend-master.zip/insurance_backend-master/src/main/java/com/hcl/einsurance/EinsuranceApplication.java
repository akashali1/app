package com.hcl.einsurance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EinsuranceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EinsuranceApplication.class, args);
	}

}
