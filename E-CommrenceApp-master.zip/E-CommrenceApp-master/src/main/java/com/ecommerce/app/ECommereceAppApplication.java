package com.ecommerce.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ECommereceAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ECommereceAppApplication.class, args);
	}

}
