package com.project.hcl.service;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public interface EmployeeService {
	
	public List<?> getSeniorLeve();
	
	
	

}
