package com.project.hcl.dto;

public class ParkingDto {
	
	private Long parkingId;
	private String ParkingStatus;
	public Long getParkingId() {
		return parkingId;
	}
	public void setParkingId(Long parkingId) {
		this.parkingId = parkingId;
	}
	public String getParkingStatus() {
		return ParkingStatus;
	}
	public void setParkingStatus(String parkingStatus) {
		ParkingStatus = parkingStatus;
	}
	
	

}
