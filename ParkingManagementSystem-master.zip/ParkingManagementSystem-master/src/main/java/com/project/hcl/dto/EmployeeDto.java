package com.project.hcl.dto;

public class EmployeeDto {
	
	private Long employeeId;
	private String employeeName;
	private int employeeExperience;
	private String employeeDes;
	public Long getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Long employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public int getEmployeeExperience() {
		return employeeExperience;
	}
	public void setEmployeeExperience(int employeeExperience) {
		this.employeeExperience = employeeExperience;
	}
	public String getEmployeeDes() {
		return employeeDes;
	}
	public void setEmployeeDes(String employeeDes) {
		this.employeeDes = employeeDes;
	}

	
}
