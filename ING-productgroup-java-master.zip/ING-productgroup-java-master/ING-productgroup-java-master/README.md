# ING-modelgroup-java
Backend code
