package com.ing.bank.registration.service;

import com.ing.bank.common.exception.IngException;
import com.ing.bank.registration.entity.Customer;

public interface CustomerService {
	
	public String register(Customer customer) throws IngException;

}
