package com.ing.bank.registration.dto;

import java.util.Date;

import javax.persistence.Column;

public class CustomerDTO {

	private String accountNum;

	private String firstName;

	private String lastName;

	private Date dob;
	
	private long balance;

	private AddressDTO permanetAddress;
	private AddressDTO residenceAddres;

	private String accountType;

	public AddressDTO getPermanetAddress() {
		return permanetAddress;
	}

	public void setPermanetAddress(AddressDTO permanetAddress) {
		this.permanetAddress = permanetAddress;
	}

	public AddressDTO getResidenceAddres() {
		return residenceAddres;
	}

	public void setResidenceAddres(AddressDTO residenceAddres) {
		this.residenceAddres = residenceAddres;
	}

	public String getAccountNum() {
		return accountNum;
	}

	public void setAccountNum(String accountNum) {
		this.accountNum = accountNum;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}
	
	

	public long getBalance() {
		return balance;
	}

	public void setBalance(long balance) {
		this.balance = balance;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

}
