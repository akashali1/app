package com.ing.bank.registration.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ing.bank.registration.entity.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Long> {

	@Query("SELECT COUNT(cust) FROM Customer cust WHERE cust.accountNum =:accountNum ")
	int findByAccountNum(@Param("accountNum") String accountNum);

}
