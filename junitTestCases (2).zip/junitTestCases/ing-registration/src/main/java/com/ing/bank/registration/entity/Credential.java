package com.ing.bank.registration.entity;

public class Credential {
	
	

}
