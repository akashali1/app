package com.ing.bank.transfer.entity;

public class Payer {
	
	private String payerName;
	private String payerAccount;
	private long balnace;


}
