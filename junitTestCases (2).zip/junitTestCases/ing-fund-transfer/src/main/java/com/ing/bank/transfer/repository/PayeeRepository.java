package com.ing.bank.transfer.repository;

public interface PayeeRepository {

}
