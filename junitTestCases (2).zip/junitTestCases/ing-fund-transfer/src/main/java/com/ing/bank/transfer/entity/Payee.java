package com.ing.bank.transfer.entity;

public class Payee {

}
