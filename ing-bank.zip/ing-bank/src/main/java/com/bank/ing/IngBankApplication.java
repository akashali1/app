package com.bank.ing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IngBankApplication {

	public static void main(String[] args) {
		SpringApplication.run(IngBankApplication.class, args);
	}

}
