package com.hcl.ticketbooking.dto;

public class BookingStatusUpdateResponse {

}
