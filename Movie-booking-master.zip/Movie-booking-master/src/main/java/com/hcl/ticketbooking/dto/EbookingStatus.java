package com.hcl.ticketbooking.dto;

public enum EbookingStatus {
	
	PENDING,BOOKED,CANCEL

}
