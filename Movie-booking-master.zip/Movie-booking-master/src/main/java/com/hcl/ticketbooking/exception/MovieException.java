package com.hcl.ticketbooking.exception;

public class MovieException extends RuntimeException {
	
 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

public	MovieException(String mesage){
	 
	 super(mesage);
		
	}

}
