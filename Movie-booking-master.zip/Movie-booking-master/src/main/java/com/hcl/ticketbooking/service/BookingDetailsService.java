package com.hcl.ticketbooking.service;

import com.hcl.ticketbooking.dto.BookingDetailsDTO;

public interface BookingDetailsService {
	
	public BookingDetailsDTO bookingDetails(Integer bookingId);

}
