package com.hcl.ticketbooking.service;

import java.util.List;

import com.hcl.ticketbooking.dto.MovieDTO;

public interface MovieService {
	
	public List<MovieDTO> movieList();

}
