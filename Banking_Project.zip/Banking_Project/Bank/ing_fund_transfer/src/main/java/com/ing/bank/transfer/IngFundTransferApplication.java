package com.ing.bank.transfer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IngFundTransferApplication {

	public static void main(String[] args) {
		SpringApplication.run(IngFundTransferApplication.class, args);
	}

}
