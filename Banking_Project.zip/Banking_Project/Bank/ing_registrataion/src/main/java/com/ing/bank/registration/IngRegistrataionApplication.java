package com.ing.bank.registration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IngRegistrataionApplication {

	public static void main(String[] args) {
		SpringApplication.run(IngRegistrataionApplication.class, args);
	}

}
