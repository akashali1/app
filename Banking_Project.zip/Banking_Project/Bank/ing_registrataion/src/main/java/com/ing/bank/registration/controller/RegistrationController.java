package com.ing.bank.registration.controller;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ing.bank.registration.entity.Customer;
import com.ing.bank.registration.repository.RegistrationRepository;

@RestController
//@RequestMapping("/bank")
public class RegistrationController {

	@Autowired
	private RegistrationRepository regRepo;
	
	@PostMapping(path = "/register", consumes = "application/json", produces = "application/json")
	public void register(@RequestBody Customer customer) {
		
		/*
		 * customer.setFristName("akash"); customer.setLastName("ali");
		 * customer.setBalance(10000); customer.setAccountType("123435");
		 */
		regRepo.save(customer);
	}
	
}
	
	
