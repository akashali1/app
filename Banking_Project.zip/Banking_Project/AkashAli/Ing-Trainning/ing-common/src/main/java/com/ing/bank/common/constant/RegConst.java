package com.ing.bank.common.constant;

public class RegConst {
	
	public static final int minBalace=10000;
	

}
