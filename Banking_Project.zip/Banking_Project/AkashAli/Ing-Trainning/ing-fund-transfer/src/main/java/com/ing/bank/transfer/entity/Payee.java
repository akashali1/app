package com.ing.bank.transfer.entity;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="payee")
public class Payee {
	
	private long payeeID;
	private String payeeFirstName;
	private String payeeLastName;
	private String payeeAccountNum;
	private long payeeBalance;
	private String payeeBank;
	private String PayeeIfscCode;
	

}
