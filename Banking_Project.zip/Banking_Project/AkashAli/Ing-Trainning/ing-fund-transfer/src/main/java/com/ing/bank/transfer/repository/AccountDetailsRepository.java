package com.ing.bank.transfer.repository;

public class AccountDetailsRepository{

}
