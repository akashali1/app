package com.ing.bank.registration.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ing.bank.common.exception.IngException;
import com.ing.bank.registration.dto.CustomerDTO;
import com.ing.bank.registration.entity.Address;
import com.ing.bank.registration.entity.Customer;
import com.ing.bank.registration.service.CustomerService;

@RestController
@RequestMapping(path = "/bank")
public class RegistrationController {

	@Autowired
	private CustomerService customerService;

	@PostMapping(path = "/registration", consumes = "application/json", produces = "application/json")
	public String register(@RequestBody CustomerDTO customerDTO) {

		Customer customer = new Customer();
		customer.setAccountNum(customerDTO.getAccountNum());
		customer.setFirstName(customerDTO.getFirstName());
		customer.setLastName(customerDTO.getLastName());
		customer.setDob(customerDTO.getDob());
		customer.setBalance(customerDTO.getBalance());
		customer.setAccountType(customerDTO.getAccountType());

		List<Address> addessList = prepareAddress(customerDTO);
		customer.setAddressList(addessList);
		
		try {
			customerService.register(customer);
		} catch (IngException e) {
			String err=e.getErrMsg();
			return err;
		}

		return "Success";
	}

	private List<Address> prepareAddress(CustomerDTO customerDTO) {
		List<Address> addessList = new ArrayList<>();

		Address permannetAddess = new Address();
		permannetAddess.setLine1(customerDTO.getPermanetAddress().getLine1());
		permannetAddess.setLine2(customerDTO.getPermanetAddress().getLine2());
		permannetAddess.setCity(customerDTO.getPermanetAddress().getCity());
		permannetAddess.setState(customerDTO.getPermanetAddress().getState());
		permannetAddess.setCountry(customerDTO.getPermanetAddress().getCountry());
		permannetAddess.setZip(customerDTO.getPermanetAddress().getZip());
		
		addessList.add(permannetAddess);

		Address regidentAddess = new Address();
		regidentAddess.setLine1(customerDTO.getResidenceAddres().getLine1());
		regidentAddess.setLine2(customerDTO.getResidenceAddres().getLine2());
		regidentAddess.setCity(customerDTO.getResidenceAddres().getCity());
		regidentAddess.setState(customerDTO.getResidenceAddres().getState());
		regidentAddess.setCountry(customerDTO.getResidenceAddres().getCountry());
		regidentAddess.setZip(customerDTO.getResidenceAddres().getZip());
		
		addessList.add(regidentAddess);
		
		return addessList;
	}

	@GetMapping(path = "/check")
	public String check(@RequestParam("name") String name) {

		System.out.println(name);

		return "Success";
	}

}
