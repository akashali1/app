package com.ing.bank.registration.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ing.bank.common.exception.IngException;
import com.ing.bank.registration.entity.Customer;
import com.ing.bank.registration.repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerRepository customerRepository;

	@Override
	public String register(Customer customer) throws IngException {

		int custCount = customerRepository.findByAccountNum(customer.getAccountNum());
		System.out.println("CustomerServiceImpl.register()  count  "+custCount);
		if (custCount > 0) {
			throw new IngException("Customer already registered", "SRV_1000");
		}
		
		Customer SavedCustomer = customerRepository.save(customer);

		if (SavedCustomer != null) {
			return "Success";
		} else {
			throw new IngException("Customer FisrtName should not Null", "SRV_1001");
		}

	}

}
