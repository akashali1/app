package com.hcl.ingproduct.service;

import java.util.List;

import com.hcl.ingproduct.entity.Category;

public interface CategoryService {
		
		List<Category> getAllProductCategory();
}
