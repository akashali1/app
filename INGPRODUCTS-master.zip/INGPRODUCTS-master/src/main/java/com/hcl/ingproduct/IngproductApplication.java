package com.hcl.ingproduct;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IngproductApplication {

	public static void main(String[] args) {
		SpringApplication.run(IngproductApplication.class, args);
	}

}
