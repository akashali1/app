package com.hcl.util;

public class IngConstants {

	private IngConstants() {
		
	}
	
	public static final String LOGIN_FAILURE = "Please Enter Correct Coustmer Id";
	public static final String LOGIN_SUCCESS = "Logged in Successfully";
}
