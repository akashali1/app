package com.hcl.exception;

public class IngBankException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	public IngBankException(String message) {
		super(message);
	}

}
